﻿namespace Practica02_ej10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C3_0 = new Label();
            C0_3 = new Label();
            C3_2 = new Label();
            C2_3 = new Label();
            C1_3 = new Label();
            C3_1 = new Label();
            C3_3 = new Label();
            Up = new Button();
            Down = new Button();
            Right = new Button();
            Left = new Button();
            C1_2 = new Label();
            C2_2 = new Label();
            C2_1 = new Label();
            C2_0 = new Label();
            C0_1 = new Label();
            C0_0 = new Label();
            C0_2 = new Label();
            C1_1 = new Label();
            C1_0 = new Label();
            Lose = new TextBox();
            Win = new TextBox();
            SuspendLayout();
            // 
            // C3_0
            // 
            C3_0.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C3_0.AutoSize = true;
            C3_0.BackColor = SystemColors.AppWorkspace;
            C3_0.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C3_0.Location = new Point(173, 466);
            C3_0.MaximumSize = new Size(3, 3);
            C3_0.MinimumSize = new Size(100, 107);
            C3_0.Name = "C3_0";
            C3_0.Size = new Size(100, 107);
            C3_0.TabIndex = 3;
            C3_0.TextAlign = ContentAlignment.MiddleCenter;
            C3_0.Click += C3_0_Click;
            // 
            // C0_3
            // 
            C0_3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C0_3.AutoSize = true;
            C0_3.BackColor = SystemColors.AppWorkspace;
            C0_3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C0_3.Location = new Point(489, 115);
            C0_3.MaximumSize = new Size(3, 3);
            C0_3.MinimumSize = new Size(100, 107);
            C0_3.Name = "C0_3";
            C0_3.Size = new Size(100, 107);
            C0_3.TabIndex = 6;
            C0_3.TextAlign = ContentAlignment.MiddleCenter;
            C0_3.Click += C0_3_Click;
            // 
            // C3_2
            // 
            C3_2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C3_2.AutoSize = true;
            C3_2.BackColor = SystemColors.AppWorkspace;
            C3_2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C3_2.Location = new Point(383, 466);
            C3_2.MaximumSize = new Size(3, 3);
            C3_2.MinimumSize = new Size(100, 107);
            C3_2.Name = "C3_2";
            C3_2.Size = new Size(100, 107);
            C3_2.TabIndex = 10;
            C3_2.TextAlign = ContentAlignment.MiddleCenter;
            C3_2.Click += C3_2_Click;
            // 
            // C2_3
            // 
            C2_3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C2_3.AutoSize = true;
            C2_3.BackColor = SystemColors.AppWorkspace;
            C2_3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C2_3.Location = new Point(489, 350);
            C2_3.MaximumSize = new Size(3, 3);
            C2_3.MinimumSize = new Size(100, 107);
            C2_3.Name = "C2_3";
            C2_3.Size = new Size(100, 107);
            C2_3.TabIndex = 11;
            C2_3.TextAlign = ContentAlignment.MiddleCenter;
            C2_3.Click += C2_3_Click;
            // 
            // C1_3
            // 
            C1_3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C1_3.AutoSize = true;
            C1_3.BackColor = SystemColors.AppWorkspace;
            C1_3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C1_3.Location = new Point(489, 233);
            C1_3.MaximumSize = new Size(3, 3);
            C1_3.MinimumSize = new Size(100, 107);
            C1_3.Name = "C1_3";
            C1_3.Size = new Size(100, 107);
            C1_3.TabIndex = 12;
            C1_3.TextAlign = ContentAlignment.MiddleCenter;
            C1_3.Click += C1_3_Click;
            // 
            // C3_1
            // 
            C3_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C3_1.AutoSize = true;
            C3_1.BackColor = SystemColors.AppWorkspace;
            C3_1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C3_1.Location = new Point(279, 466);
            C3_1.MaximumSize = new Size(3, 3);
            C3_1.MinimumSize = new Size(100, 107);
            C3_1.Name = "C3_1";
            C3_1.Size = new Size(100, 107);
            C3_1.TabIndex = 13;
            C3_1.TextAlign = ContentAlignment.MiddleCenter;
            C3_1.Click += C3_1_Click;
            // 
            // C3_3
            // 
            C3_3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C3_3.AutoSize = true;
            C3_3.BackColor = Color.DarkGray;
            C3_3.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C3_3.Location = new Point(489, 466);
            C3_3.MaximumSize = new Size(3, 3);
            C3_3.MinimumSize = new Size(100, 107);
            C3_3.Name = "C3_3";
            C3_3.Size = new Size(100, 107);
            C3_3.TabIndex = 15;
            C3_3.TextAlign = ContentAlignment.MiddleCenter;
            C3_3.Click += C3_3_Click;
            // 
            // Up
            // 
            Up.BackColor = Color.CadetBlue;
            Up.Font = new Font("Yu Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Up.Location = new Point(305, 33);
            Up.Name = "Up";
            Up.Size = new Size(147, 59);
            Up.TabIndex = 16;
            Up.Text = "Up";
            Up.UseVisualStyleBackColor = false;
            Up.Click += Up_Click;
            // 
            // Down
            // 
            Down.BackColor = Color.CadetBlue;
            Down.Font = new Font("Yu Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Down.Location = new Point(305, 602);
            Down.Name = "Down";
            Down.Size = new Size(147, 59);
            Down.TabIndex = 17;
            Down.Text = "Down";
            Down.UseVisualStyleBackColor = false;
            Down.Click += Down_Click;
            // 
            // Right
            // 
            Right.BackColor = Color.CadetBlue;
            Right.Font = new Font("Yu Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Right.Location = new Point(607, 319);
            Right.Name = "Right";
            Right.Size = new Size(147, 59);
            Right.TabIndex = 18;
            Right.Text = "Right";
            Right.UseVisualStyleBackColor = false;
            Right.Click += Right_Click;
            // 
            // Left
            // 
            Left.BackColor = Color.CadetBlue;
            Left.Font = new Font("Yu Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            Left.Location = new Point(12, 319);
            Left.Name = "Left";
            Left.Size = new Size(147, 59);
            Left.TabIndex = 19;
            Left.Text = "Left";
            Left.UseVisualStyleBackColor = false;
            Left.Click += Left_Click;
            // 
            // C1_2
            // 
            C1_2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C1_2.AutoSize = true;
            C1_2.BackColor = Color.DarkGray;
            C1_2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C1_2.Location = new Point(383, 233);
            C1_2.MaximumSize = new Size(3, 3);
            C1_2.MinimumSize = new Size(100, 107);
            C1_2.Name = "C1_2";
            C1_2.Size = new Size(100, 107);
            C1_2.TabIndex = 20;
            C1_2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C2_2
            // 
            C2_2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C2_2.AutoSize = true;
            C2_2.BackColor = Color.DarkGray;
            C2_2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C2_2.Location = new Point(383, 350);
            C2_2.MaximumSize = new Size(3, 3);
            C2_2.MinimumSize = new Size(100, 107);
            C2_2.Name = "C2_2";
            C2_2.Size = new Size(100, 107);
            C2_2.TabIndex = 21;
            C2_2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C2_1
            // 
            C2_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C2_1.AutoSize = true;
            C2_1.BackColor = Color.DarkGray;
            C2_1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C2_1.Location = new Point(279, 350);
            C2_1.MaximumSize = new Size(3, 3);
            C2_1.MinimumSize = new Size(100, 107);
            C2_1.Name = "C2_1";
            C2_1.Size = new Size(100, 107);
            C2_1.TabIndex = 22;
            C2_1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C2_0
            // 
            C2_0.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C2_0.AutoSize = true;
            C2_0.BackColor = Color.DarkGray;
            C2_0.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C2_0.Location = new Point(173, 350);
            C2_0.MaximumSize = new Size(3, 3);
            C2_0.MinimumSize = new Size(100, 107);
            C2_0.Name = "C2_0";
            C2_0.Size = new Size(100, 107);
            C2_0.TabIndex = 23;
            C2_0.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C0_1
            // 
            C0_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C0_1.AutoSize = true;
            C0_1.BackColor = Color.DarkGray;
            C0_1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C0_1.Location = new Point(279, 115);
            C0_1.MaximumSize = new Size(3, 3);
            C0_1.MinimumSize = new Size(100, 107);
            C0_1.Name = "C0_1";
            C0_1.Size = new Size(100, 107);
            C0_1.TabIndex = 24;
            C0_1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C0_0
            // 
            C0_0.AccessibleRole = AccessibleRole.Text;
            C0_0.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C0_0.AutoSize = true;
            C0_0.BackColor = Color.DarkGray;
            C0_0.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C0_0.Location = new Point(173, 115);
            C0_0.MaximumSize = new Size(3, 3);
            C0_0.MinimumSize = new Size(100, 107);
            C0_0.Name = "C0_0";
            C0_0.Size = new Size(100, 107);
            C0_0.TabIndex = 25;
            C0_0.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C0_2
            // 
            C0_2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C0_2.AutoSize = true;
            C0_2.BackColor = Color.DarkGray;
            C0_2.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C0_2.Location = new Point(383, 115);
            C0_2.MaximumSize = new Size(3, 3);
            C0_2.MinimumSize = new Size(100, 107);
            C0_2.Name = "C0_2";
            C0_2.Size = new Size(100, 107);
            C0_2.TabIndex = 26;
            C0_2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C1_1
            // 
            C1_1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C1_1.AutoSize = true;
            C1_1.BackColor = Color.DarkGray;
            C1_1.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C1_1.Location = new Point(279, 233);
            C1_1.MaximumSize = new Size(3, 3);
            C1_1.MinimumSize = new Size(100, 107);
            C1_1.Name = "C1_1";
            C1_1.Size = new Size(100, 107);
            C1_1.TabIndex = 27;
            C1_1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // C1_0
            // 
            C1_0.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            C1_0.AutoSize = true;
            C1_0.BackColor = Color.DarkGray;
            C1_0.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            C1_0.Location = new Point(173, 233);
            C1_0.MaximumSize = new Size(3, 3);
            C1_0.MinimumSize = new Size(100, 107);
            C1_0.Name = "C1_0";
            C1_0.Size = new Size(100, 107);
            C1_0.TabIndex = 28;
            C1_0.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Lose
            // 
            Lose.Enabled = false;
            Lose.Font = new Font("Yu Gothic", 50F, FontStyle.Bold, GraphicsUnit.Point);
            Lose.Location = new Point(58, 285);
            Lose.Name = "Lose";
            Lose.ReadOnly = true;
            Lose.Size = new Size(635, 114);
            Lose.TabIndex = 29;
            Lose.Text = "HAS PERDIDO";
            Lose.TextAlign = HorizontalAlignment.Center;
            Lose.Visible = false;
            Lose.TextChanged += Lose_TextChanged;
            // 
            // Win
            // 
            Win.Enabled = false;
            Win.Font = new Font("Yu Gothic", 50F, FontStyle.Bold, GraphicsUnit.Point);
            Win.Location = new Point(58, 285);
            Win.Name = "Win";
            Win.ReadOnly = true;
            Win.Size = new Size(635, 114);
            Win.TabIndex = 31;
            Win.Text = "HAS GANADO";
            Win.TextAlign = HorizontalAlignment.Center;
            Win.Visible = false;
            Win.TextChanged += Win_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(772, 695);
            Controls.Add(Win);
            Controls.Add(Lose);
            Controls.Add(C1_0);
            Controls.Add(C1_1);
            Controls.Add(C0_2);
            Controls.Add(C0_0);
            Controls.Add(C0_1);
            Controls.Add(C2_0);
            Controls.Add(C2_1);
            Controls.Add(C2_2);
            Controls.Add(C1_2);
            Controls.Add(Left);
            Controls.Add(Right);
            Controls.Add(Down);
            Controls.Add(Up);
            Controls.Add(C3_3);
            Controls.Add(C3_1);
            Controls.Add(C1_3);
            Controls.Add(C2_3);
            Controls.Add(C3_2);
            Controls.Add(C0_3);
            Controls.Add(C3_0);
            Font = new Font("Yu Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Form1";
            Text = "2048 App";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Up;
        private Button Down;
        private Button Right;
        private Button Left;
        private Label C3_0;
        private Label C0_3;
        private Label C3_2;
        private Label C2_3;
        private Label C1_3;
        private Label C3_1;
        private Label C3_3;
        private Label C1_2;
        private Label C2_2;
        private Label C2_1;
        private Label C2_0;
        private Label C0_1;
        private Label C0_0;
        private Label C0_2;
        private Label C1_1;
        private Label C1_0;
        private TextBox Lose;
        private TextBox Win;
    }
}