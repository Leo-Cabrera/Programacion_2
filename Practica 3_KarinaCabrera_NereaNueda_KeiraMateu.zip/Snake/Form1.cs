﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    public partial class Form1 : Form
    {
        public const Keys arriba = Keys.Up, abajo = Keys.Down, derecha = Keys.Right, izquierda = Keys.Left;
        Serpiente serpiente;
        Comida comida;
        Marcador marcador;
        Stopwatch timer = new Stopwatch();
        double ultimoTiempo = 0;
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (serpiente.ChoqueCola())
            {
                return;
            }
            if (serpiente.ChoquePared())
            {
                return;
            }
            if (marcador.tiempo <= 0)
            {
                return;
            }
            double tiempoActual = timer.ElapsedMilliseconds;
            double tiempoPasado = tiempoActual - ultimoTiempo;
            ultimoTiempo = tiempoActual;
            marcador.tiempo -= tiempoPasado/1000;


            serpiente.Mover();
            comida.ActualizarComida();
            marcador.Actualizar();


            serpiente.Dibujar();
            comida.Dibujar();
            marcador.Dibujar();
            
            Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case arriba:
                    serpiente.Girar(arriba);
                    break;
                case abajo:
                    serpiente.Girar(abajo);
                    break;
                case derecha:
                    serpiente.Girar(derecha);
                    break;
                case izquierda:
                    serpiente.Girar(izquierda);
                    break;
            }
        }

        public const int anchura = 735, altura = 500;
        public Form1()
        {
            InitializeComponent();
            this.ClientSize = new Size(anchura, altura);
            marcador = new Marcador(this);
            serpiente = new Serpiente(this);
            comida = new Comida(this, serpiente, marcador);
            timer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
    public class Serpiente
    {
        Segmento cabeza;
        List<Segmento> cola = new List<Segmento>();
        List<Giro> giros = new List<Giro>();
        Form ventana;
        public Serpiente(Form _ventana)
        {
            ventana = _ventana;
            int x = Form1.anchura / 2;
            int y = Form1.altura / 2;
            cabeza = new Segmento(x, y, Color.Green, Form1.arriba, ventana);
            cola.Add(new Segmento(x, y + Segmento.anchura, Color.LightGreen, Form1.arriba, ventana));

            cola.Add(new Segmento(x, y + Segmento.anchura*2, Color.LightGreen, Form1.arriba, ventana));
        }
        public void Mover()
        {
            cabeza.Mover();
            for(int i = 0; i < cola.Count; i++)
            {
                Segmento seg = cola[i];
                seg.Mover();
                for(int j = 0; j < giros.Count; j++)
                {
                    Giro giro = giros[j];
                    if (seg.box.Left == giro.x && seg.box.Top == giro.y)
                    {
                        seg.direccion = giro.direccion;
                        if(i == cola.Count - 1)
                        {
                            giros.RemoveAt(j);
                        }
                        break;
                    }
                }
            }
        }
        public void Dibujar()
        {
            cabeza.Dibujar();
            foreach(Segmento seg in cola)
            {
                seg.Dibujar();
            }
        }
        public void Girar(Keys direccion)
        {
            cabeza.direccion = direccion;
            giros.Add(new Giro(cabeza.box.Left, cabeza.box.Top, cabeza.direccion));
        }
        public void Alargar()
        {
            Segmento ultimoSeg = cola[cola.Count - 1];
            int newX = ultimoSeg.box.Left;
            int newY = ultimoSeg.box.Top;
            switch (ultimoSeg.direccion)
            {
                case Form1.arriba:
                    newY += Segmento.anchura;
                    break;
                case Form1.abajo:
                    newY -= Segmento.anchura;
                    break;
                case Form1.derecha:
                    newX -= Segmento.anchura;
                    break;
                case Form1.izquierda:
                    newX += Segmento.anchura;
                    break;
            }
            cola.Add(new Segmento(newX, newY, Color.LightGreen, ultimoSeg.direccion, ventana));
        }
        public bool ChoqueCola()
        {
            for(int i = 1; i < cola.Count; i++)
            {
                if (cola[i].box.Bounds.IntersectsWith(cabeza.box.Bounds))
                {
                    return true;
                }
            }
            return false;
        }
        public bool ChoqueCabeza(PictureBox box)
        {
            if(cabeza.box.Bounds.IntersectsWith(box.Bounds))
            {
                return true;
            }
            return false;
        }
        public bool ChoquePared()
        {
            if(cabeza.box.Left <= 0 || cabeza.box.Left >= Form1.anchura || cabeza.box.Top <= 0 || cabeza.box.Top >= Form1.altura)
            {
                return true;
            }
            return false;
        }
    }
    public class Giro
    {
        public int x, y;
        public Keys direccion;
        public Giro(int x, int y, Keys direccion)
        {
            this.x = x;
            this.y = y;
            this.direccion = direccion;
        }
    }
    public class Segmento
    {
        public const int anchura = 15;
        public PictureBox box;
        public Keys direccion;
        public Segmento(int x, int y, Color color, Keys dir, Form ventana)
        {
            direccion = dir;
            box = new PictureBox();
            box.Size = new Size(anchura, anchura);
            box.Location = new Point(x, y);
            box.BackColor = color;
            
            ventana.Controls.Add(box);
            box.BringToFront();
        }
        public void Dibujar()
        {
            box.Refresh();
        }
        public void Mover()
        {
            switch (direccion)
            {
                case Form1.arriba:
                    box.Top -= 1;
                    break;
                case Form1.abajo:
                    box.Top += 1;
                    break;
                case Form1.derecha:
                    box.Left += 1;
                    break;
                case Form1.izquierda:
                    box.Left -= 1;
                    break;
            }
        }
    }

    public class Comida
    {
        Form ventana;
        Serpiente serpiente;
        List<Bocado> bocados = new List<Bocado>();
        Random random = new Random();
        Marcador marcador;
        public Comida(Form ventana, Serpiente serpiente, Marcador marcador)
        {
            this.marcador = marcador;
            this.ventana = ventana;
            this.serpiente = serpiente;
            for(int i = 0; i < random.Next(2, 5);i++) {
                CrearBocado();
            }

        }
        public void ActualizarComida()
        {
            for(int i = 0; i < bocados.Count; i++)
            {
                if (serpiente.ChoqueCabeza(bocados[i].box))
                {
                    Bocado boc = bocados[i];

                    bocados.RemoveAt(i);
                    ventana.Controls.Remove(boc.box);
                    CrearBocado();
                    marcador.puntos += boc.puntos;
                    marcador.tiempo += boc.tiempoVida;
                    serpiente.Alargar();
                }
            }
        }

        void CrearBocado()
        {
            int x = random.Next(0, Form1.anchura - Bocado.anchura);
            int y = random.Next(0, Form1.altura - Bocado.anchura);
            int tiempoVida = random.Next(10,17);
            int puntos = random.Next(2, 7);
            Color color = CrearColor(puntos);
            bocados.Add(new Bocado(x, y, color, ventana, tiempoVida, puntos));

        }
        Color CrearColor(int puntos) {
            switch (puntos)
            {
                case 2:
                    return Color.Red;
                case 3:
                    return Color.Blue;
                case 4:
                    return Color.Purple;
                case 5:
                    return Color.Indigo;
                case 6:
                    return Color.Gold;
            }
            return Color.Black;
        }
        public void Dibujar()
        {
            foreach (Bocado bocado in bocados)
            {
                bocado.Dibujar();
            }
        }
    }

    public class Bocado
    {
        public const int anchura = 15;
        public PictureBox box;
        public int tiempoVida, puntos;
        public Bocado(int x, int y, Color color, Form ventana, int tiempoVida, int puntos)
        {
            this.tiempoVida = tiempoVida;
            this.puntos = puntos;
            box = new PictureBox();
            box.Size = new Size(anchura, anchura);
            box.Location = new Point(x, y);
            box.BackColor = color;
            
            ventana.Controls.Add(box);
            box.BringToFront();
        }
        public void Dibujar()
        {
            box.Refresh();
        }
    }

    public class Marcador
    {
        Label label;
        public double tiempo = 10;
        public int puntos;
        public Marcador(Form ventana) 
        {
            label = new Label();
            label.Location = new Point(0, 0);
            label.AutoSize = true;
            label.Font = new Font("Ariel", 18);
            ventana.Controls.Add(label);
        }
        public void Actualizar()
        {
            label.Text = "Tiempo de vida: " + tiempo.ToString("0") + "\nPuntos: " + puntos;
        }
        public void Dibujar()
        {
            label.Refresh();
        }
    }
}
